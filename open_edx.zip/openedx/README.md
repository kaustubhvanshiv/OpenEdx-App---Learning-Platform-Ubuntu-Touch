# OpenEdX on the Go: A Mobile Learning App for Ubuntu Touch/Lomiri

## Overview
Open edX on the Go is a QML/JavaScript app for Ubuntu Touch / Lomiri that allows users to browse and enroll in Open edX courses, view content, and manage downloads for offline use.

## Features
- Course browsing and search
- Enrollment & progress tracking
- Video playback and content viewing
- Offline downloads and sync queue
- User authentication (Open edX credentials)
- Settings and cache management

## Tech Stack
- UI: QML + JavaScript (Lomiri Components)
- API: Open edX REST API via `js/api.js`
- Storage: `localStorage` (client-side JSON/SQLite fallback)
- Packaging: Clickable (Ubuntu Touch), Snap (Lomiri/Snap) optionally

## Getting started (development)
1. Install Clickable:
```bash
sudo snap install clickable --classic

## License

Copyright (C) 2025  Kaustubh Vrushal Vanshiv

Licensed under the MIT license.
